@{
GUID="{a5bd98e1-e44c-44fb-b88f-5af9bde66fdf}"
Author="Microsoft Corporation"
CompanyName="Microsoft Corporation"
Copyright="© Microsoft Corporation. All rights reserved."
ModuleVersion="2.0.0.0"
ModuleToProcess="Microsoft.SecureBoot.Commands"
PowerShellVersion = '5.1'
CLRVersion="4.0"
CmdletsToExport=
	"Confirm-SecureBootUEFI",
	"Set-SecureBootUEFI",
	"Get-SecureBootUEFI",
	"Format-SecureBootUEFI",
	"Get-SecureBootPolicy"
HelpInfoUri="https://aka.ms/winsvr-2022-pshelp"
CompatiblePSEditions = @('Desktop','Core')
}
